const mongoose = require('mongoose');

// Define the user schema
const userSchema = new mongoose.Schema({
    userId: {
        type: String,
        default: () => uuidv4()
    },
    name: String,
    email: String,
    password: String
});

const orderSchema = new mongoose.Schema({
    userId: String,
    name: String,
    status: String,
    items: [itemSchema]
});

const itemSchema = new mongoose.Schema({
    name: String,
    price: Number,
    quantity: Number
});

module.exports = {
    userSchema,
    orderSchema,
    itemSchema
};


